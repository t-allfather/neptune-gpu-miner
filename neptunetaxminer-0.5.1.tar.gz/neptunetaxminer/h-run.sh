. h-manifest.conf

CONF=$(cat $CUSTOM_CONFIG_FILENAME)
./neptune-gpu-taxminer $CONF
